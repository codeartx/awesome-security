|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |  1114 | daffainfo     |   558 | cves             |  1116 | info     |  1157 | http    |  3103 |
| panel     |   503 | dhiyaneshdk   |   415 | exposed-panels   |   509 | high     |   854 | file    |    60 |
| lfi       |   454 | pikpikcu      |   315 | vulnerabilities  |   445 | medium   |   642 | network |    49 |
| xss       |   351 | pdteam        |   261 | technologies     |   249 | critical |   401 | dns     |    17 |
| wordpress |   341 | geeknik       |   177 | exposures        |   199 | low      |   178 |         |       |
| exposure  |   287 | dwisiswant0   |   165 | misconfiguration |   194 | unknown  |     6 |         |       |
| rce       |   281 | princechaddha |   127 | workflows        |   185 |          |       |         |       |
| cve2021   |   273 | 0x_akoko      |   126 | token-spray      |   152 |          |       |         |       |
| tech      |   263 | gy741         |   115 | default-logins   |    93 |          |       |         |       |
| wp-plugin |   246 | pussycat0x    |   107 | takeovers        |    67 |          |       |         |       |
